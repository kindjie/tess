# Correctness evidence clarification

This append-only correction supersedes the normal-suite count sentence in
`README.md`. The normal suite completed 1,568 tests with 1,567 passed, one
intentionally skipped unsupported allocation-failure-injection capability,
no failures, and process status 0. The retained `dev-ctest.log` and
`dev-ctest.status` are authoritative.

`EXACT-TREE-IDENTITY.txt` supplies the exact source-commit and clean tracked,
staged, and untracked source-tree evidence omitted from the first correctness
manifest. The original files and manifests remain unchanged.
