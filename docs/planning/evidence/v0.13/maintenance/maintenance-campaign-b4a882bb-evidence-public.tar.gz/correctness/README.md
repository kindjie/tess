# Exact-commit correctness evidence

This directory records the correctness gate rerun against source commit
`b4a882bbdaa32a704109d5bdd773a1adfe45b492`, the exact implementation measured
by the paired M3 and Steam Deck campaigns. All commands completed with status
0. The retained logs replace the local source-root prefix with `<source>`;
test names, results, counts, timing, diagnostics, and tool versions are
otherwise unchanged.

The commands were:

```text
cmake --build --preset dev
ctest --preset dev
cmake --build --preset dev-asan
ctest --preset dev-asan -R '^TessChunkMaintenance\.'
cmake --build --preset dev-tsan
ctest --preset dev-tsan -R '^TessChunkMaintenance\.'
cmake --build --preset dev-werror
ctest --preset dev-werror -R '^TessChunkMaintenance\.'
pytest tests/test_maintenance_campaign.py tests/test_steamdeck_tools.py
```

The normal suite passed 1,568 of 1,568 tests, with the intentionally
unsupported allocation-failure-injection capability skipped once. The
adapter-focused ASan/UBSan, TSan, and warnings-as-errors runs each passed all
21 cases. The campaign and Steam Deck tool suites passed all 43 cases.

The adapter cases include the deterministic 1,000-run flush, independent
rescan and world-archive-v2 equivalence, dirty-mask ownership, strongly typed
content and residency generation checks, generation-safe clear, bounded
capacity and retry, budget continuation, callback exception recovery,
shutdown/release behavior, producer/drain concurrency, and warmed zero-
allocation checks across every backend and dense/sparse storage.
