# M3 scaling-4096 peak-RSS observation

This is descriptive evidence only. The frozen campaign does not define a
memory promotion threshold, and none is introduced after seeing the result.

The device report records maximum per-process peak RSS across 30 isolated
observations as 5,008 KiB for dirty-bit, 3,744 KiB for coalescing, 4,928 KiB
for FIFO, and 4,736 KiB for immediate. The raw distribution shows that each
larger maximum is a single observation rather than a sustained backend level:

- dirty-bit: 3,632 / 3,656 / 5,008 KiB minimum/median/maximum; 29 of 30
  observations are 3,632-3,664 KiB, with the 5,008 KiB maximum at repetition
  24;
- coalescing: 3,712 / 3,744 / 3,744 KiB;
- FIFO: 3,568 / 3,616 / 4,928 KiB, with its maximum at repetition 9;
- immediate: 3,472 / 3,504 / 4,736 KiB, with its maximum at repetition 27.

Every observation executes in a fresh benchmark process. Dirty-bit RSS is not
monotonic with repetition, its median is lower than coalescing, and independent
FIFO and immediate processes show similar one-off roughly 1.3 MiB excursions.
All scaling-4096 work counters remain exact (4,096 registered slots, offers,
executions, and rebuilds; 65,536 scanned values; zero capacity failures).
Together with the green allocation/sanitizer/correctness gates, this pattern is
consistent with fixed registered storage plus process-level peak-RSS noise,
not a leak or correctness failure. The Steam Deck leg should retain the same
raw RSS evidence; no cross-device absolute-memory comparison is valid.
