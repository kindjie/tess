# Superseded M3 campaign attempt

- Frozen source: `b4a882bbdaa32a704109d5bdd773a1adfe45b492`
- Attempt: `m3-results`
- Failed phase: calibration
- Recorded at: `2026-08-20T08:20:03Z`
- Exit status: 2
- Phase checksum digest:
  `7659cdd1b8e74c8e7c4724d21b43d721fd3df1cd0fc9425e7d6c878c3b2810e8`
- Invalidation reason: the sandbox denied the collector's read-only
  `sysctl -n machdep.cpu.brand_string` subprocess. The collector therefore
  returned an unknown CPU model and the frozen hardware-binding gate rejected
  the phase before any benchmark invocation. An out-of-sandbox read-only query
  confirmed the expected `Apple M3 Max` model.
- Disposition: preserve this exact failed result set. Stage a new immutable
  result directory and run the whole calibration and candidate phases outside
  the filesystem sandbox. Do not reuse or overwrite this attempt.
