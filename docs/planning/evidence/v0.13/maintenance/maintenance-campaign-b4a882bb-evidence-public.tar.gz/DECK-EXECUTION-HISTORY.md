# Deck campaign execution history (public sanitized transcription)

This is the public sanitized transcription of the raw execution history.
The raw record's SHA-256 is
`aef7046997b13eee83de36ceffe2b5e10da63e7bd52da905abeaaae6ae0e9b0a`
and is bound by `CROSS_DEVICE_EVIDENCE_V4_SHA256SUMS`. The placeholder
`<deck-home>` replaces the Deck user home directory prefix; no other
content differs from the raw record.

This record supplements the immutable raw phase artifacts. Host aliases and
local absolute paths are sanitized. The exact frozen source is
`b4a882bbdaa32a704109d5bdd773a1adfe45b492` and the Deck bundle-manifest
identity is
`1fa6323d8166cb81ffdb888bcc912932e31c5ec0f8633f44b0cd2c8cdda3dee5`.

## Failed run 3

- Run ID: `b4a882b-20260820-03`
- Intended phase: calibration
- Outcome: remote phase exit 1 before collection because the Deck runner's
  non-interactive `sudo tee` calls still required a password.
- Phase-manifest digest:
  `fe6ba2328016e8d591db0384dc717169a8b8459e9939bb91db3c816f3dc838a6`
- Stderr digest:
  `9d8eac806ad342871ade4db6db95c5c6386f3a50a87f81f7b0f5dd2068c7da0f`
- The before/after governor snapshots are byte-identical. No calibration JSON,
  threshold manifest, or benchmark observations exist.
- Disposition: preserve the exact six-file result set. It is superseded
  infrastructure evidence and is excluded from measurement evidence.

## Successful run 4

- Run ID: `b4a882b-20260820-04`
- Exact remote bundle:
  `<deck-home>/tess-maintenance-campaign-b4a882bbdaa32a704109d5bdd773a1adfe45b492/runs/b4a882b-20260820-04/bundle`
- Exact remote results:
  `<deck-home>/tess-maintenance-campaign-b4a882bbdaa32a704109d5bdd773a1adfe45b492/runs/b4a882b-20260820-04/results`
- Root helper: `privilege/run-deck-campaign-root.sh`, SHA-256
  `c1c10dcb9f0afe958fdd19d11921b30c6d4c7dc6bc7f59130d87e567e6097544`.
- User invocation: `sudo bash ~/r` on the Deck console. The helper exported
  `HOME=<deck-home>`, verified the expected runner and fresh result path, then
  invoked the frozen remote runner for calibration followed by candidate under
  the same bundle, result directory, and privilege context.
- The wrapper's overall console output and process exit status were not
  separately captured. They are not claimed as known. The closed raw evidence
  instead proves both phase exit-status files are 0; both phase manifests and
  inventories verify; and the process tree was absent afterward.
- The wrapper EXIT trap removed `/etc/sudoers.d/g`, `<deck-home>/g`, and
  `<deck-home>/g2`. A read-only post-exit check confirmed all three absent and
  confirmed the remote results directory was `deck:deck` mode 755.
- Retrieval attempt 1 used an unsupported macOS `rsync --protect-args` option
  and failed locally before copying; the destination was confirmed absent.
- Successful sanitized retrieval command:

  ```sh
  rsync -a \
    <deck-host>:<deck-home>/tess-maintenance-campaign-b4a882bbdaa32a704109d5bdd773a1adfe45b492/runs/b4a882b-20260820-04/results/ \
    "$EVIDENCE_ROOT/deck-results-run4/"
  ```

- Local verification found both phase status files equal to 0; all calibration
  and candidate manifest entries valid; before/during/after governor snapshots
  byte-identical for each phase; and both retained stderr logs empty.
- Independent threshold and device-report replay are byte-identical to the
  retained outputs. The report digest is
  `2c78fbc48559bd7ee1b0f3531840c0a5af738fd369f406aa5d5cd4f31928d68c`.
- Independent cross-device replay produced digest
  `6f56204e7b2c738d33dc75d4b8f4f084f759da8d6bde70933600dbbd119520fd`
  and decision `keep_experimental`.

Per-phase logs, exit statuses, governor snapshots, raw JSON, reports, and
checksums are the authoritative execution evidence. No separate wrapper-console
transcript is retained.
