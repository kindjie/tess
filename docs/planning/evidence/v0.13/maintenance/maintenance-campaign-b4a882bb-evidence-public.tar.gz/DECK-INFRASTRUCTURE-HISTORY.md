# Deck campaign infrastructure history

## Host preflight attempt 1

- Source: `b4a882bbdaa32a704109d5bdd773a1adfe45b492`
- Run ID: `b4a882b-20260820-01`
- Intended phase: calibration
- Outcome: host route exit 143 during `tools/steamdeck/deck doctor`
- Cause: the shared Docker Desktop API was unresponsive and `docker info`
  remained blocked. Several unrelated Docker CLI calls were also blocked.
- Scope reached: host-only Docker preflight. No SSH, transfer, remote directory,
  governor mutation, benchmark invocation, or timing occurred.
- Local results: the intended result directory remained empty.
- Disposition: excluded from admissible measurement evidence. After authorized
  termination of only the stuck doctor and its `docker info` child, Docker
  Desktop was recovered externally. Retry uses a fresh run ID and result
  directory while preserving the exact frozen bundle.

## Deck calibration attempt 2

- Source: `b4a882bbdaa32a704109d5bdd773a1adfe45b492`
- Run ID: `b4a882b-20260820-02`
- Intended phase: calibration
- Outcome: remote phase exit 1 before benchmark collection
- Phase-manifest digest:
  `fe6ba2328016e8d591db0384dc717169a8b8459e9939bb91db3c816f3dc838a6`
- Bundle-manifest digest:
  `1fa6323d8166cb81ffdb888bcc912932e31c5ec0f8633f44b0cd2c8cdda3dee5`
- Cause: the remote runner could not perform non-interactive governor writes;
  `sudo` required a terminal and password.
- State evidence: all eight CPUs reported `performance` before the attempt and
  the after snapshot is byte-identical. Pin and restore commands failed before
  collection; no calibration JSON or benchmark observation payload exists.
- Disposition: retain the exact six-file failed result set. Do not reuse its run
  ID or result directory. Retry only after a supported non-interactive governor
  authorization path is explicitly configured, using a new run ID and result
  directory.
